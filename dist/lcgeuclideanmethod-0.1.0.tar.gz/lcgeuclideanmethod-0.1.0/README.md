LCG T-TEST USING EUCLIDEAN METHOD
---------------------------------
Advanced Analytics and Growth Marketing Telkomsel
-------------------------------------------------
Project Supervisor : Rizli Anshari
Writer             : Azka Rohbiya Ramadani, Muhammad Gilang, Demi Lazuardi

This project has been created for statistical usage, purposing for determining ATL takers and nontakers using LCG ttest and Euclidean Method.

This python requires related package
more importantly python_requires='>=3.1', so that package can be install
Make sure the other packages meet the requirements below
'pandas>=1.1.5',
'numpy>=1.18.5',
'scipy>=1.2.0',
'matplotlib>=3.1.0',
'statsmodels>=0.8.0'